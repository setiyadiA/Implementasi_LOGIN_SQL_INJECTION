<?php
$host = "localhost";
$user = "root";
$pass = "root"; // Ganti jika ada password
$db = "test_db";
$port = "3307";

// Koneksi ke database
$conn = new mysqli($host, $user, $pass, $db, $port);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Query tanpa proteksi (sengaja untuk testing SQL Injection)
$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);

// Siapkan hasil
$success = $result->num_rows > 0;
$message = $success 
    ? "Login berhasil. Selamat datang, <strong>$username</strong>!"
    : "Login gagal. Username atau password salah.";

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hasil Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow rounded-4 p-4" style="max-width: 500px; width: 100%;">
        <h3 class="text-center mb-3">Login Result</h3>

        <div class="alert <?php echo $success ? 'alert-success' : 'alert-danger'; ?> text-center" role="alert">
            <?php echo $message; ?>
        </div>

        <div class="text-center">
            <a href="login.html" class="btn btn-secondary">Kembali ke Login</a>
        </div>
    </div>
</div>

</body>
</html>